---
title: "week2"
author: "Dinesh"
date: "2024-04-14"
output: html_document
---

# LOADING LIBRARIES ----
library(mlr)        # Loads the 'mlr' package for machine learning in R, which provides tools for training, predicting, and evaluating machine learning models.
library(tidyverse)  # Loads the 'tidyverse' collection of packages designed for data manipulation, visualization, and analysis.

# LOADING DIABETES DATA ----
data(diabetes, package = "mclust")  # Loads the 'diabetes' dataset from the 'mclust' package, which is typically used for model-based clustering.
diabetesTib <- as_tibble(diabetes)  # Converts the 'diabetes' dataset into a tibble, enhancing data handling and visualization within the tidyverse framework.

# DEFINING THE DIABETES TASK ----
diabetesTask <- makeClassifTask(data = diabetesTib, target = "class")
# `makeClassifTask` creates a classification task for the machine learning model.
# - data: The dataset used for the task.
# - target: Specifies the target variable ("class") which is the outcome variable the model needs to predict.

# DEFINING THE KNN LEARNER ----
knn <- makeLearner("classif.knn", par.vals = list("k" = 2))
# `makeLearner` sets up a machine learning model, in this case, a k-Nearest Neighbors (kNN) classifier.
# - "classif.knn": Indicates that the learner is a kNN classifier.
# - par.vals: Parameters values for the learner, here 'k' is set to 2, which means the model uses the two nearest neighbors to determine the class.

# LISTING ALL OF MLR'S LEARNERS ----
listLearners()$class
# Lists all available machine learning algorithms in 'mlr' with their class type.

# Listing learners by function:
listLearners("classif")$class
# Lists all classification learners available in 'mlr'.

listLearners("regr")$class
# Lists all regression learners available in 'mlr'.

listLearners("cluster")$class
# Lists all clustering algorithms available in 'mlr'.

# DEFINE MODEL ----
knnModel <- train(knn, diabetesTask)
# `train` function is used to train the model on the specified task.
# - knn: The kNN learner defined earlier.
# - diabetesTask: The classification task defined for the diabetes dataset.

# TESTING PERFORMANCE ON TRAINING DATA (VERY BAD PRACTICE) ----
knnPred <- predict(knnModel, newdata = diabetesTib)
# `predict` function generates predictions from a trained model.
# - knnModel: The trained kNN model.
# - newdata: The data used for making predictions; here it's the same as the training data, which is not recommended as it can lead to overfitting.

performance(knnPred, measures = list(mmce, acc))
# `performance` evaluates the prediction quality of the model.
# - knnPred: The predictions made by the kNN model.
# - measures: Performance measures used; mmce (mean misclassification error) and acc (accuracy).

# PERFORMING HOLD-OUT CROSS-VALIDATION ----
holdout <- makeResampleDesc(method = "Holdout", split = 2/3, stratify = TRUE)
# `makeResampleDesc` sets up a description for resampling methods used in model validation.
# - method: "Holdout" indicates a simple split between training and test sets.
# - split: Specifies the proportion of data used for training (2/3 in this case).
# - stratify: Ensures that each class is proportionally represented in both training and testing sets.

holdoutCV <- resample(learner = knn, task = diabetesTask, resampling = holdout, measures = list(mmce, acc))
# `resample` performs the resampling procedure to validate the model.
# - learner: The kNN learner.
# - task: The classification task.
# - resampling: The resampling description.
# - measures: Performance measures.

holdoutCV$aggr
calculateConfusionMatrix(holdoutCV$pred, relative = TRUE)
# `calculateConfusionMatrix` computes a confusion matrix to evaluate classification accuracy in a relative format.

# PERFORMING REPEATED K-FOLD CROSS-VALIDATION ----
kFold <- makeResampleDesc(method = "RepCV", folds = 10, reps = 50, stratify = TRUE)
# - method: "RepCV" specifies repeated cross-validation.
# - folds: Number of folds (10) used in each repetition.
# - reps: Number of repetitions (50).
# - stratify: Ensures proportional class representation.

kFoldCV <- resample(learner = knn, task = diabetesTask, resampling = kFold, measures = list(mmce, acc))
# Repeats the k-fold cross-validation procedure to robustly evaluate model performance.

kFoldCV$aggr
kFoldCV$measures.test
calculateConfusionMatrix(kFoldCV$pred, relative = TRUE)
# Outputs aggregated performance measures and calculates the confusion matrix for detailed accuracy analysis.
