---
title: "week2"
author: "Dinesh"
date: "2024-04-14"
output: html_document
---
  

# LOADING LIBRARIES ----
library(mlr)        # Loads the 'mlr' package, which is useful for machine learning tasks in R.
library(tidyverse)  # Loads the 'tidyverse', a collection of packages for data manipulation, visualization, and programming.

# LOADING DIABETES DATA ----
data(diabetes, package = "mclust")  # Loads the 'diabetes' dataset from the 'mclust' package, which includes functionalities for model-based clustering and classification.
diabetesTib <- as_tibble(diabetes)  # Converts the 'diabetes' data frame to a tibble for more modern and flexible data manipulation capabilities.

# CREATING LOO RESAMPLE DESCRIPTION ----
looDesc <- makeResampleDesc(method = "LOO")
# Creates a resample description using Leave-One-Out (LOO) cross-validation. LOO uses each data point as a test set while the remainder serves as the training set.

# CREATING KNN LEARNER ----
knn <- makeLearner("classif.knn", par.vals = list("k" = 2))
# Initializes a k-Nearest Neighbors learner for classification tasks with the number of neighbors (k) set to 2.

# Creating LOO resampling object with KNN
LOOCV <- resample(learner = knn, task = diabetesTask, resampling = looDesc, measures = list(mmce, acc))
# Performs LOO cross-validation using the kNN learner defined. Measures performance using mean misclassification error (mmce) and accuracy (acc).

LOOCV$aggr
calculateConfusionMatrix(LOOCV$pred, relative = TRUE)
# Displays aggregated results of the resampling and calculates a confusion matrix based on the predictions to evaluate classification performance in relative terms.

# Loading Libraries
library("BBmisc")
library("ParamHelpers")
# Loads additional libraries: 'BBmisc' for miscellaneous helper functions in Bioinformatics and 'ParamHelpers' for parameter descriptions and manipulations.

# Creating LOO Resample Description
LOO <- makeResampleDesc(method = "LOO")
# Another instance of creating a LOO resample description without any additional parameters.

# The following lines include erroneous attempts to modify the LOO method:
# Uncomment the line below only when using it alone
makeResampleDesc(method = "LOO", stratify = TRUE)
# Incorrect usage as LOO cannot be stratified. Stratification ensures equal representation of classes in each fold which isn't applicable when each fold is a single data point.

# Uncomment the line below only when using it alone
makeResampleDesc(method = "LOO", reps = 5)
# Incorrect usage as LOO cannot be repeated in the traditional sense. Each instance is used exactly once as a test set.

