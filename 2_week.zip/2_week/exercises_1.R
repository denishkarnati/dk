---
title: "week2"
author: "Dinesh"
date: "2024-04-14"
output: html_document
---
  

# LOADING LIBRARIES ----
library(mlr)        # Loads the 'mlr' package, which provides tools for machine learning in R.
library(tidyverse)  # Loads the 'tidyverse', a collection of R packages for data manipulation, visualization, and analysis.

# LOADING DIABETES DATA ----
data(diabetes, package = "mclust")  # Loads the 'diabetes' dataset from the 'mclust' package into the R environment.
diabetesTib <- as_tibble(diabetes)  # Converts the 'diabetes' data frame to a tibble for easier data manipulation and printing.

# PLOTTING GLUCOSE VS INSULIN ----
# First Plot
ggplot(diabetesTib, aes(glucose, insulin, shape = class)) +  # Initializes a ggplot for the 'diabetesTib' data, setting 'glucose' as x-axis and 'insulin' as y-axis. Uses 'class' to change the shape of points.
  geom_point()  +  # Adds points to the plot, with different shapes based on the 'class' attribute.
  theme_bw()       # Applies a minimalistic theme with a white background.

# Second Plot
ggplot(diabetesTib, aes(glucose, insulin, shape = class, col = class)) +  # Similar to the first plot, but also colors the points according to 'class'.
  geom_point()  +  # Adds colored and shaped points to the plot.
  theme_bw()       # Uses the same minimalistic white background theme.
