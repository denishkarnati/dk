---
title: "week2"
author: "Dinesh"
date: "2024-04-14"
output: html_document
---
  

# LOADING LIBRARIES ----
library(mlr)        # Loads the 'mlr' library, which includes functions for creating, tuning, and evaluating machine learning models in R.
library(tidyverse)  # Loads the 'tidyverse', a suite of R packages designed for data science, facilitating data manipulation and visualization.

# LOADING IRIS DATA ----
data(iris)
irisTask <- makeClassifTask(data = iris, target = "Species")
# `makeClassifTask` creates a machine learning task for classification.
# - data: The dataset to use, here the well-known Iris dataset.
# - target: The variable that the model needs to predict, "Species" in this case, which indicates the type of iris plant.

# CREATING RESAMPLE DESCRIPTIONS FOR INNER AND OUTER CROSS-VALIDATION ----
inner <- makeResampleDesc("CV")
# Creates a description for inner cross-validation. Here, the method "CV" stands for standard cross-validation.
outerHoldout <- makeResampleDesc("Holdout", split = 2/3, stratify = TRUE)
# Creates a description for outer holdout cross-validation.
# - split = 2/3: Indicates that 2/3 of the data will be used for training and the remaining 1/3 for testing.
# - stratify = TRUE: Ensures that the training and testing sets have approximately the same percentage of samples of each target class as the complete set.

# CREATING A TUNE WRAPPER FOR K-NEAREST NEIGHBORS ----
knnWrapper <- makeTuneWrapper("classif.knn", resampling = inner, par.set = knnParamSpace, control = gridSearch)
# `makeTuneWrapper` creates a wrapper learner that includes both the model training and the hyperparameter tuning process.
# - "classif.knn": Specifies the learning model, k-Nearest Neighbors, for classification.
# - resampling = inner: Uses the inner cross-validation setup for the hyperparameter tuning phase.
# - par.set: The set of hyperparameters that should be tuned.
# - control: The control settings for the tuning, specifying how the tuning should be conducted (e.g., using a grid search).

# RESAMPLING WITH TUNING USING HOLDOUT AND DISPLAYING THE RESULTS ----
holdoutCVWithTuning <- resample(knnWrapper, irisTask, resampling = outerHoldout)
# `resample` function performs the resampling using the specified learner (here, the tuned kNN wrapper), task, and resampling method.
# - knnWrapper: The learner that includes the hyperparameter tuning.
# - irisTask: The classification task based on the Iris dataset.
# - resampling = outerHoldout: Specifies that the holdout method defined earlier will be used for evaluating the model performance.
holdoutCVWithTuning
# This command outputs the results from the holdout cross-validation, providing performance metrics and insights into the effectiveness of the model with the tuned parameters.
