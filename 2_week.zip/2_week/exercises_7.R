---
title: "week2"
author: "Dinesh"
date: "2024-04-14"
output: html_document
---
  

# LOADING LIBRARIES ----
# Load required libraries
library(mlr)        # For machine learning tasks and resampling
library(tidyverse)  # For data manipulation and visualization

# LOADING IRIS DATA ----
# Load the iris dataset
data(iris)
# Create a classification task from the iris dataset, with the target variable being "Species"
irisTask <- makeClassifTask(data = iris, target = "Species")

# CREATING RESAMPLE DESCRIPTIONS FOR OUTER K-FOLD CROSS-VALIDATION ----
# Create a resampling description for outer k-fold cross-validation with 5 folds and stratification
outerKfold <- makeResampleDesc("CV", iters = 5, stratify = TRUE)

# CREATING A TUNE WRAPPER FOR K-NEAREST NEIGHBORS ----
# Create a tuning wrapper for the k-nearest neighbors algorithm
# This wrapper will be used for hyperparameter tuning
# 'classif.knn' specifies the classification task for k-nearest neighbors
# 'resampling = inner' indicates that inner resampling will be used for hyperparameter tuning
# 'par.set = knnParamSpace' specifies the parameter space for k-nearest neighbors
# 'control = gridSearch' indicates grid search as the tuning method
knnWrapper <- makeTuneWrapper("classif.knn", resampling = inner, par.set = knnParamSpace, control = gridSearch) 

# RESAMPLING WITH TUNING USING K-FOLD AND DISPLAYING THE RESULTS ----
# Perform resampling with hyperparameter tuning using outer k-fold cross-validation
kFoldCVWithTuning <- resample(knnWrapper, irisTask, resampling = outerKfold)
# Display the results of resampling with tuning
kFoldCVWithTuning

# REPEATING EACH VALIDATION PROCEDURE 10 TIMES AND SAVING THE MMCE VALUES ----
# Perform resampling with hyperparameter tuning 10 times for k-fold cross-validation and save the mean misclassification error (MMCE) values
kSamples <- map_dbl(1:10, ~resample(knnWrapper, irisTask, resampling = outerKfold)$aggr)
# Perform resampling with hyperparameter tuning 10 times for holdout validation and save the mean misclassification error (MMCE) values
hSamples <- map_dbl(1:10, ~resample(knnWrapper, irisTask, resampling = outerHoldout)$aggr)

# DISPLAYING HISTOGRAMS OF MMCE VALUES FOR K-FOLD AND HOLDOUT ----
# Display a histogram of MMCE values for k-fold cross-validation
hist(kSamples, xlim = c(0, 0.11))
# Display a histogram of MMCE values for holdout validation
hist(hSamples, xlim = c(0, 0.11))
