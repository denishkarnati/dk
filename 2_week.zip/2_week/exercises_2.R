---
title: "week2"
author: "Dinesh"
date: "2024-04-14"
output: html_document
---

# LOADING LIBRARIES ----
library(mlr)        # Loads the 'mlr' library, which provides machine learning tools in R. It offers functions for creating and evaluating machine learning models.
library(tidyverse)  # Loads the 'tidyverse' set of packages which include ggplot2, dplyr, tidyr, readr, and more, providing tools for data manipulation and visualization.

# LOADING DIABETES DATA ----
data(diabetes, package = "mclust")  # This function loads the 'diabetes' dataset from the 'mclust' package. 'mclust' is primarily used for model-based clustering, classification, and density estimation.
diabetesTib <- as_tibble(diabetes)  # Converts the loaded 'diabetes' dataset into a tibble (a modern reimagining of data frames in R) using 'as_tibble' from the 'tibble' package (part of tidyverse) for better handling and printing.

# CREATING HOLDOUT RESAMPLE DESCRIPTION WITHOUT STRATIFICATION ----
holdoutNoStrat <- makeResampleDesc(method = "Holdout", split = 0.9, stratify = FALSE)
# `makeResampleDesc` is a function from the 'mlr' package used to create a description of a resampling strategy for model training and testing.
# Parameters:
# - method = "Holdout": Specifies the resampling method as holdout, which is a simple split of the dataset into training and testing sets.
# - split = 0.9: Sets the proportion of the dataset to be used for training; here, 90% of the data is used for training and the remaining 10% for testing.
# - stratify = FALSE: Indicates that the split should not be stratified. Stratification would ensure that each class is proportionally represented in both training and testing sets; setting this to FALSE means the split could be unbalanced in terms of class representation.
