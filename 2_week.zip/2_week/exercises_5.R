---
title: "week2"
author: "Dinesh"
date: "2024-04-14"
output: html_document
---
  

# LOADING LIBRARIES ----
library(mlr)        # Loads the 'mlr' package, which is used for machine learning in R, providing tools for creating, tuning, and evaluating models.
library(tidyverse)  # Loads the 'tidyverse', a collection of data manipulation and visualization packages, enhancing data handling and graphical capabilities.

# LOADING IRIS DATA ----
data(iris)
irisTask <- makeClassifTask(data = iris, target = "Species")
# `makeClassifTask` creates a classification task for the machine learning model.
# - data: Specifies the dataset to be used, here it's the 'iris' dataset.
# - target: Defines the variable to predict, here it's "Species", which is the label for iris plant species.

# TUNING HYPERPARAMETERS FOR K ----
knnParamSpace <- makeParamSet(makeDiscreteParam("k", values = 1:25))
# `makeParamSet` and `makeDiscreteParam` are used to define the space over which hyperparameters will be optimized.
# - "k": Specifies the hyperparameter 'k' for the k-Nearest Neighbors algorithm, which is the number of neighbors to consider.
# - values = 1:25: Defines a range of values from 1 to 25 that 'k' can take.

gridSearch <- makeTuneControlGrid()
# `makeTuneControlGrid` sets up a control object for systematic grid search in hyperparameter tuning.

cvForTuning <- makeResampleDesc("RepCV", folds = 10, reps = 20)
# `makeResampleDesc` sets up a resampling strategy for model evaluation during tuning.
# - "RepCV": Specifies repeated cross-validation.
# - folds = 10: The number of folds per repetition.
# - reps = 20: The number of repetitions of the cross-validation process.

tunedK <- tuneParams("classif.knn", task = irisTask, resampling = cvForTuning, par.set = knnParamSpace, control = gridSearch)
# `tuneParams` performs hyperparameter tuning.
# - "classif.knn": Indicates the type of model, a k-Nearest Neighbors classifier.
# - task: The machine learning task defined earlier.
# - resampling: The resampling description defined for tuning.
# - par.set: The set of hyperparameters to tune.
# - control: The control settings for the tuning, here using grid search.

# DISPLAYING TUNED HYPERPARAMETERS AND PLOTTING THE EFFECT OF K ----
tunedK
tunedK$x
knnTuningData <- generateHyperParsEffectData(tunedK)
# `generateHyperParsEffectData` processes the results of hyperparameter tuning to prepare data for plotting the effects of parameters.

plotHyperParsEffect(knnTuningData, x = "k", y = "mmce.test.mean", plot.type = "line") + theme_bw()
# `plotHyperParsEffect` creates a plot to visualize the effects of different hyperparameter values on model performance.
# - x = "k": Plots the hyperparameter 'k' on the x-axis.
# - y = "mmce.test.mean": Plots the mean misclassification error on the y-axis, averaged over test sets.
# - plot.type = "line": Specifies a line plot.
# `theme_bw()`: Adds a theme with a white background to the plot for better readability.

# TRAINING THE FINAL MODEL WITH TUNED HYPERPARAMETERS ----
tunedKnn <- setHyperPars(makeLearner("classif.knn"), par.vals = tunedK$x)
# `setHyperPars` configures a learning algorithm with optimal hyperparameters.
# - makeLearner("classif.knn"): Creates a new kNN learner.
# - par.vals = tunedK$x: Sets the tuned hyperparameters to the learner.

tunedKnnModel <- train(tunedKnn, irisTask)
# `train` function is used to train the model on the specified task using the learner with tuned parameters.
